\#!/bin/bash
date
current_time=$(date +%s) 
echo "Current time is : $current_time"
let current_time=current_time*2
echo "Current time  is : $current_time"
for i in {1..20}; do echo "Number: $i"
done


